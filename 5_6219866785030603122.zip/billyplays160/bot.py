from telebot import TeleBot

TOKEN = "<telegram_bot_token>"
URL = "https://your-heroku-app-name.herokuapp.com/"

bot = TeleBot(TOKEN, parse_mode = "Markdown", threaded = False)
bot.bot_info = bot.get_me()
bot.remove_webhook()
# bot.set_webhook("https://f26f9dc69ebd.ngrok.io/" + bot.token)
bot.set_webhook(URL + bot.token)
