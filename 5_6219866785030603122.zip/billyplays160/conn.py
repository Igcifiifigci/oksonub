import sqlite3

db = sqlite3.connect("database.db", check_same_thread = False)
db.row_factory = lambda c, r: dict([(col[0], r[idx]) for idx, col in enumerate(c.description)])
cur = db.cursor()