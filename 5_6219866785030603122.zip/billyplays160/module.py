from telebot import types
from conn import db, cur
from characters import characters
import time, re

def button(*args, **kwargs):
	markup = types.ReplyKeyboardMarkup(resize_keyboard = True, **kwargs)
	for arg in args:
		instance = type(arg)
		if instance == str:
			markup.row(types.KeyboardButton(arg))
		elif instance in [list, tuple]:
			markup.row(*[types.KeyboardButton(x) for x in arg])

	return markup


def inline(*args, **kwargs):
	markup = types.InlineKeyboardMarkup(**kwargs)
	for arg in args:
		instance = type(arg)
		if instance == str:
			markup.row(types.InlineKeyboardButton(arg, callback_data = arg))
		elif instance in [list, tuple]:
			markup.row(*[types.InlineKeyboardButton(x, callback_data = x) for x in arg])

	return markup


def getTotalGold(previousClaim, gpm, max = None):
	timeNow = int(time.time())

	if (timeNow - previousClaim <= 60):
		return 0

	total = ((timeNow - previousClaim) // 60) * gpm
	
	if max and total > max:
		total = max

	return total


def removeMarkdown(string):
	return re.sub(r"[*_`]", "", string)


def createMention(from_user):
	return f"[{removeMarkdown(from_user.first_name)}](tg://user?id={from_user.id})"


def getBarPersentase(current, total):
	a = "█"
	b = "▒"

	persen = round(current / total * 100)

	if persen <= 0:
		string = a * 1 + b * 9
	elif persen >= 100:
		string = a * 10
	elif persen >= 90:
		string = a * 9 + b * 1
	elif persen >= 80:
		string = a * 8 + b * 2
	elif persen >= 70:
		string = a * 7 + b * 3
	elif persen >= 60:
		string = a * 6 + b * 4
	elif persen >= 50:
		string = a * 5 + b * 5
	elif persen >= 40:
		string = a * 4 + b * 6
	elif persen >= 30:
		string = a * 3 + b * 7
	elif persen >= 20:
		string = a * 2 + b * 8
	else:
		string = a * 1 + b * 9

	return string


def getExpRequirement(level):
	return round(30 * (level + 1) ** 1.8)


def getTotalExpRequirement(levelFrom, levelTo):
	return sum([getExpRequirement(level) for level in range(levelFrom, levelTo)])


# def getLevel(exp):
# 	for level in range(100):
# 		if getExpRequirement(level) >= exp:
# 			return level
# 	else:
# 		return 100


def addExp(companion_id, exp, companion = None):
	if not companion:
		cur.execute(f"SELECT * FROM companion WHERE companion_id = {companion_id}")
		companion = cur.fetchone()

	if companion["level"] >= 100:
		return

	companionClass = characters[companion["name"]]
	currentExp = companion["exp"]
	totalExp = currentExp + exp

	for i in range(companion["level"], 101):
		a = getTotalExpRequirement(companion["level"], i)
		if a > totalExp:
			nextLevel = i - 1
			break

	b = getTotalExpRequirement(companion["level"], nextLevel)
	
	# print(a, b, totalExp, exp)
	if totalExp >= b:
		exp = totalExp - b
	else:
		exp = totalExp

	cur.execute(f"UPDATE companion SET level = {nextLevel}, exp = {exp} WHERE companion_id = {companion_id}")
	db.commit()