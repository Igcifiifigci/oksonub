from threading import Timer
from conn import db, cur
from telebot import types
from bot import bot
import characters, module, random, time

IN_ROOM_BATTLE = []
ROOM_BATTLE = {}
MSG_ID = {}

def checkUser(func):
	def inner(call):
		if MSG_ID.get(call.from_user.id) == call.message.message_id:
			return func(call)
		else:
			bot.answer_callback_query(callback_query_id = call.id, text = "Can't use this operation")


	return inner


# def createCode(func):
# 	def inner(message):
# 		rand = str(random.randint(1, 1000000))

# 		def code(string):
# 			return string + "|" + rand
# 		return code

# 	return inner


def noInRoomBattle(tele_id):
	return not tele_id in IN_ROOM_BATTLE


class RoomBattle:
	def __init__(self, group_info, player1_info, player2_info, msg_id):
		self.group_info = group_info
		self.player1_info = player1_info
		self.player2_info = player2_info
		self.player1_companions = []
		self.player2_companions = []
		self.msg_id = msg_id
		self.player1_turn = None
		self.timer = None
		self.started = False
		self.msg = "Battle begins!"
		self.total_damage = {}
		self.getPosition()

		MSG_ID[player1_info.id] = msg_id
		MSG_ID[player2_info.id] = msg_id

		if noInRoomBattle(player1_info.id):
			IN_ROOM_BATTLE.append(player1_info.id)

		if noInRoomBattle(player2_info.id):
			IN_ROOM_BATTLE.append(player2_info.id)

		self.timer = Timer(60, self.cancel, args = (self.player1_info.id,))
		self.timer.start()
		self.p1_reward = round(sum([x.level * 1.5 for x in self.player2_companions]))
		self.p2_reward = round(sum([x.level * 1.5 for x in self.player1_companions]))


	def cancel(self, tele_id):
		if self.started or tele_id != self.player1_info.id:
			return

		bot.edit_message_text("Challange cancelled", chat_id = self.group_info.id, message_id = self.msg_id)
		IN_ROOM_BATTLE.remove(self.player1_info.id)
		IN_ROOM_BATTLE.remove(self.player2_info.id)
		self.timer.cancel()


	def accept(self, tele_id):
		if self.started or tele_id != self.player2_info.id:
			return

		self.started = True
		bot.edit_message_text("Challange accepted", chat_id = self.group_info.id, message_id = self.msg_id)
		self.timer.cancel()
		self.start()


	def reject(self, tele_id):
		if self.started or tele_id != self.player2_info.id:
			return

		bot.edit_message_text("Challange rejected", chat_id = self.group_info.id, message_id = self.msg_id)
		IN_ROOM_BATTLE.remove(self.player1_info.id)
		IN_ROOM_BATTLE.remove(self.player2_info.id)
		self.timer.cancel()


	def getCharacterInfo(self, characterObject):
		return f"""
{characterObject.name}

Level : {characterObject.level}
Element : {characterObject.element}
HP : {characterObject.hp}
Attack : {characterObject.attack}
Speed : {characterObject.speed}

⚔️ Default Moveset :
*{characterObject.first_skill_name}* : {characterObject.first_skill_info}

⚔️ Moveset unlock at level 50:
*{characterObject.second_skill_name}* : {characterObject.second_skill_info}
		"""


	def getMsg(self, characterObject1, characterObject2):
		# print(self.player1_companions)
		# print(self.player2_companions)
		if self.player1_turn:
			currentTurn = module.createMention(self.player1_info)
		else:
			currentTurn = module.createMention(self.player2_info)

		msg = f"""
{self.msg}

Current turn: {currentTurn}

{module.createMention(self.player1_info)} - *{characterObject1.name2}*
*Lv.* {characterObject1.level}, *HP:* _{characterObject1.hp}/{characterObject1.totalHp}_
{module.getBarPersentase(characterObject1.hp, characterObject1.totalHp)}

{module.createMention(self.player2_info)} - *{characterObject2.name2}*
*Lv.* {characterObject2.level}, *HP:* _{characterObject2.hp}/{characterObject2.totalHp}_
{module.getBarPersentase(characterObject2.hp, characterObject2.totalHp)}
		"""
		return msg


	def getPosition(self):
		cur.execute(f"SELECT companion_id, name, level FROM companion WHERE owner = {self.player1_info.id}")
		player1_companions = cur.fetchall()
		cur.execute(f"SELECT * FROM position WHERE id = {self.player1_info.id}")
		player1_position = cur.fetchone()

		if not player1_position:
			companionList = player1_companions[:3]
			position1 = companionList[0]["name"]
			position2 = companionList[1]["name"] if len(companionList) >= 2 else "NULL"
			position3 = companionList[2]["name"] if len(companionList) >= 3 else "NULL"
			cur.execute(f"INSERT INTO position VALUES({self.player1_info.id}, {position1}, {position2}, {position3})")
			db.commit()
			cur.execute(f"SELECT * FROM position WHERE id = {self.player1_info.id}")
			player1_position = cur.fetchone()

		player1_position = (player1_position["position1"], player1_position["position2"], player1_position["position3"])

		for x in player1_position:
			for y in player1_companions:
				if x == y["name"]:
					self.player1_companions.append(characters.characters[x](y["level"], companion_id = y["companion_id"]))
					break

		cur.execute(f"SELECT companion_id, name, level FROM companion WHERE owner = {self.player2_info.id}")
		player2_companions = cur.fetchall()
		cur.execute(f"SELECT * FROM position WHERE id = {self.player2_info.id}")
		player2_position = cur.fetchone()

		if not player2_position:
			companionList = player2_companions[:3]
			position1 = companionList[0]["name"]
			position2 = companionList[1]["name"] if len(companionList) >= 2 else "NULL"
			position3 = companionList[2]["name"] if len(companionList) >= 3 else "NULL"
			cur.execute(f"INSERT INTO position VALUES({self.player2_info.id}, {position1}, {position2}, {position3})")
			db.commit()
			cur.execute(f"SELECT * FROM position WHERE id = {self.player2_info.id}")
			player2_position = cur.fetchone()

		player2_position = (player2_position["position1"], player2_position["position2"], player2_position["position3"])

		for x in player2_position:
			for y in player2_companions:
				if x == y["name"]:
					self.player2_companions.append(characters.characters[x](y["level"], companion_id = y["companion_id"]))
					break


	def start(self):
		self.getFirst()
		self.reload(change_turn = False)


	def p1Companion(self):
		for i, x in enumerate(self.player1_companions.copy()):
			if not x.isDead():
				return x
			
			bot.edit_message_text(f"{x.name} died!", chat_id = self.group_info.id, message_id = self.msg_id)
			del self.player1_companions[i]
			self.msg = "Battle begins!"
			time.sleep(3)


	def p2Companion(self):
		for i, x in enumerate(self.player2_companions.copy()):
			if not x.isDead():
				return x
			
			bot.edit_message_text(f"{x.name} died!", chat_id = self.group_info.id, message_id = self.msg_id)
			del self.player2_companions[i]
			self.msg = "Battle begins!"
			time.sleep(3)


	def getFirst(self):
		if self.p1Companion().speed >= self.p2Companion().speed:
			self.player1_turn = True
		else:
			self.player1_turn = False


	def doneBattle(self):
		try:
			IN_ROOM_BATTLE.remove(self.player1_info.id)
		except:
			pass

		try:
			IN_ROOM_BATTLE.remove(self.player2_info.id)
		except:
			pass

		try:
			del MSG_ID[self.player1_info.id]
			del MSG_ID[self.player2_info.id]
			del ROOM_BATTLE[self.player1_info.id]
			del ROOM_BATTLE[self.player2_info.id]
		except:
			pass

		for companion_id, damage in self.total_damage.items():
			# cur.execute(f"UPDATE companion SET exp = exp + {damage // 2} WHERE companion_id = {companion_id}")
			module.addExp(companion_id, damage // 8)
		db.commit()
		self.total_damage = {}


	def attack1(self):
		p1 = self.p1Companion()
		p2 = self.p2Companion()
		if self.player1_turn:
			p2hp = p2.hp
			damage = p1.attack1(p2)
			self.msg = f"{p1.name2} use *{p1.first_skill_name}*. Dealt {damage} damage."
			if not self.total_damage.get(p1.companion_id):
				self.total_damage[p1.companion_id] = 0
			self.total_damage[p1.companion_id] += (damage if p2hp > damage else p2hp)
		else:
			p1hp = p1.hp
			damage = p2.attack1(p1)
			self.msg = f"{p2.name2} use *{p2.first_skill_name}*. Dealt {damage} damage."
			if not self.total_damage.get(p2.companion_id):
				self.total_damage[p2.companion_id] = 0
			self.total_damage[p2.companion_id] += (damage if p1hp > damage else p1hp)

		self.reload()


	def attack2(self):
		p1 = self.p1Companion()
		p2 = self.p2Companion()
		if self.player1_turn:
			p2hp = p2.hp
			damage = p1.attack2(p2)
			self.msg = f"{p1.name2} use *{p1.first_skill_name}*. Dealt {damage} damage."
			if not self.total_damage.get(p1.companion_id):
				self.total_damage[p1.companion_id] = 0
			self.total_damage[p1.companion_id] += (damage if p2hp > damage else p2hp)
		else:
			p1hp = p1.hp
			damage = p2.attack2(p1)
			self.msg = f"{p2.name2} use *{p2.first_skill_name}*. Dealt {damage} damage."
			if not self.total_damage.get(p2.companion_id):
				self.total_damage[p2.companion_id] = 0
			self.total_damage[p2.companion_id] += (damage if p1hp > damage else p1hp)

		self.reload()


	def timeout(self):
		msg = """
{} didn't respond

{} won the battle

Reward : 💰 {} Gold
			"""
		if self.player1_turn:
			cur.execute(f"UPDATE data SET gold = gold + {self.p2_reward}, total_win = total_win + 1 WHERE id = {self.player2_info.id}")
			cur.execute(f"UPDATE data SET total_lose = total_lose + 1 WHERE id = {self.player1_info.id}")
			db.commit()
			bot.edit_message_text(msg.format(module.createMention(self.player1_info), module.createMention(self.player2_info), self.p2_reward), chat_id = self.group_info.id, message_id = self.msg_id)
			self.doneBattle()

		else:
			cur.execute(f"UPDATE data SET gold = gold + {self.p1_reward}, total_win = total_win + 1 WHERE id = {self.player1_info.id}")
			cur.execute(f"UPDATE data SET total_lose = total_lose + 1 WHERE id = {self.player2_info.id}")
			db.commit()
			bot.edit_message_text(msg.format(module.createMention(self.player2_info), module.createMention(self.player1_info), self.p1_reward), chat_id = self.group_info.id, message_id = self.msg_id)
			self.doneBattle() 


	def reload(self, change_turn = True):
		if change_turn:
			self.player1_turn = not self.player1_turn

		markup = types.InlineKeyboardMarkup()
		inlineButton = []

		self.timer.cancel()
		self.timer = Timer(60, self.timeout)
		self.timer.start()
		p1 = self.p1Companion()
		p2 = self.p2Companion()

		msg = """
{} won the battle

Reward : 💰 {} Gold
		"""
		if not p1:
			cur.execute(f"UPDATE data SET gold = gold + {self.p2_reward}, total_win = total_win + 1 WHERE id = {self.player2_info.id}")
			cur.execute(f"UPDATE data SET total_lose = total_lose + 1 WHERE id = {self.player1_info.id}")
			db.commit()
			bot.edit_message_text(msg.format(module.createMention(self.player2_info), self.p2_reward), chat_id = self.group_info.id, message_id = self.msg_id)
			self.doneBattle()
			return

		if not p2:
			cur.execute(f"UPDATE data SET gold = gold + {self.p1_reward}, total_win = total_win + 1 WHERE id = {self.player1_info.id}")
			cur.execute(f"UPDATE data SET total_lose = total_lose + 1 WHERE id = {self.player2_info.id}")
			db.commit()
			bot.edit_message_text(msg.format(module.createMention(self.player1_info), self.p1_reward), chat_id = self.group_info.id, message_id = self.msg_id)
			self.doneBattle() 
			return

		if self.player1_turn:
			inlineButton.append(types.InlineKeyboardButton(p1.first_skill_name, callback_data = f"attack1|{self.player1_info.id}"))
			inlineButton.append(types.InlineKeyboardButton(p1.second_skill_name, callback_data = f"attack2|{self.player1_info.id}"))
		else:
			inlineButton.append(types.InlineKeyboardButton(p2.first_skill_name, callback_data = f"attack1|{self.player2_info.id}"))
			inlineButton.append(types.InlineKeyboardButton(p2.second_skill_name, callback_data = f"attack2|{self.player2_info.id}"))

		markup.row(*inlineButton)
		msg = self.getMsg(self.p1Companion(), self.p2Companion())
		bot.edit_message_text(msg, chat_id = self.group_info.id, message_id = self.msg_id, reply_markup = markup)

	



