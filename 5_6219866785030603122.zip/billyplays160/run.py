from flask import Flask, request
from telebot import types
from conn import db, cur
from room import *
from bot import bot
from decorators import loadingFixed
import characters, elements, module, time, re, os, traceback

app = Flask(__name__)

SELECTED_COMPANION = {}
CHARACTERS_NAME = [character.name for character in characters.characters]
CHARACTERS_NAME_ASCII_ONLY = [character.name.encode("ascii", "ignore").decode().strip() for character in characters.characters]

@app.errorhandler(Exception)
def error500(e):
	print(traceback.print_exc())
	return str(e), 500


@app.route("/" + bot.token, methods = ["POST"])
def getMessage():
	message = request.get_json()
	if not message:
		return "OK"

	bot.process_new_updates([types.Update.de_json(message)])
	return "OK"


@bot.message_handler(commands = ["start"], func = lambda message: noInRoomBattle(message.from_user.id))
def start(message):
	# print(message.text)
	try:
		invitedBy = message.text.split(" ")[-1]
		invitedBy = invitedBy if invitedBy.isdigit() else "NULL" 
		cur.execute(f"INSERT INTO data VALUES({message.from_user.id}, 1000, 500, 1, 0, 0, 0, {invitedBy})")
		db.commit()
	except:
		cur.execute(f"SELECT name FROM companion WHERE owner = {message.from_user.id}")
		if cur.fetchone():
			commands(message)
			return

	char_name = [CHARACTERS_NAME[i:i + 2] for i in range(0, len(CHARACTERS_NAME), 2)]
	markup = module.inline(*char_name)
	# bot.send_message(message.from_user.id, "To begin your adventure 🚩, select one companion to follow you ⚔️", reply_markup = markup)
	bot.send_photo(message.from_user.id, open("images/Angel.jpg", "rb"), caption = "To begin your adventure 🚩, select one companion to follow you ⚔️", reply_markup = markup)


@bot.message_handler(commands = ["commands"])
def commands(message):
	msg = """
/start - to start this bot
/storage - to check your inventory 
/companion - to check your companion
/team - create your team and battle with friends
/store - to check items to buy
/battle - reply to someone in group to have a battle
/feed - to feed companion in order to gain exp
/referral - invite friends and get rewards
	"""

	if message.chat.type in ["supergroup", "group"]:
		bot.reply_to(message, msg)
	else:
		bot.send_message(message.from_user.id, msg)


@bot.callback_query_handler(func = lambda call: call.data in CHARACTERS_NAME)
@loadingFixed
def selectChar(call):
	index = CHARACTERS_NAME.index(call.data)
	character = characters.characters[index]

	cur.execute(f"SELECT name FROM companion WHERE owner = {call.message.chat.id}")
	myCompanionName = [CHARACTERS_NAME[x["name"]] for x in cur.fetchall()]
	cur.execute(f"SELECT slot FROM data WHERE id = {call.message.chat.id}")
	slot = cur.fetchone()["slot"]

	if call.data in myCompanionName:
		bot.answer_callback_query(callback_query_id = call.id, text = "You already have this companion")
		return

	if slot <= len(myCompanionName):
		bot.answer_callback_query(callback_query_id = call.id, text = "You don't have a slot")
		return

	msg = f"""
      {character.name}

Element : {character.element}
HP : {character.hp}
Attack : {character.attack}
Speed : {character.speed}

💰 Gold production/min : {character.gpm}
🗄 Max gold : {character.maxGold}

⚔️ Default Moveset :
*{character.first_skill_name}* : {character.first_skill_info}

⚔️ Moveset unlock at level 50:
*{character.second_skill_name}* : {character.second_skill_info}
	"""

	SELECTED_COMPANION[call.message.chat.id] = character
	markup = module.inline(["Confirm", "Back"])
	bot.edit_message_media(types.InputMedia("photo", open(character.imagePath, "rb"), caption = msg, parse_mode = "Markdown"), chat_id = call.message.chat.id,
						message_id = call.message.message_id, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data == "Back")
@loadingFixed
def backToSelectChar(call):
	bot.answer_callback_query(callback_query_id = call.id)
	msg = "Select one companion to follow you ⚔️"
	char_name = [CHARACTERS_NAME[i:i + 2] for i in range(0, len(CHARACTERS_NAME), 2)]
	markup = module.inline(*char_name)
	bot.edit_message_media(types.InputMedia("photo", open("images/Angel.jpg", "rb"), caption = msg), chat_id = call.message.chat.id, message_id = call.message.message_id, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data == "Confirm")
def confirmSelect(call):
	bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id)
	
	cur.execute(f"SELECT slot, gold FROM data WHERE id = {call.message.chat.id}")
	user = cur.fetchone()
	cur.execute(f"SELECT name FROM companion WHERE owner = {call.message.chat.id}")
	myCompanionNameList = [CHARACTERS_NAME[x["name"]] for x in cur.fetchall()]
	totalCompanion = len(myCompanionNameList)

	character = SELECTED_COMPANION[call.message.chat.id]
	del SELECTED_COMPANION[call.message.chat.id]

	if character.name in myCompanionNameList:
		bot.answer_callback_query(callback_query_id = call.id, text = "You already have this companion")
		return

	if user["slot"] <= totalCompanion:
		bot.answer_callback_query(callback_query_id = call.id, text = "You don't have a slot")
		return


	cur.execute(f"INSERT INTO companion VALUES(NULL, 1, {call.message.chat.id}, {CHARACTERS_NAME.index(character.name)}, \
				{int(time.time())}, 0)")
	cur.execute(f"DELETE FROM position WHERE id = {call.message.chat.id}")
	db.commit()
	msg = f"""
Congratulations 🎊
You have selected {character.name} to be your companion.

Use /commands to see command lists.

Let the adventure begin ⚔️
		"""
	bot.send_message(call.message.chat.id, msg)


@bot.message_handler(commands = ["storage"], func = lambda message: noInRoomBattle(message.from_user.id))
def getStorageData(message):
	cur.execute(f"SELECT * FROM data WHERE id = {message.from_user.id}")
	data = cur.fetchone()

	if message.chat.type in ["supergroup", "group"]:
		if not data:
			bot.reply_to(message, "Data not found")
		else:
			bot.reply_to(message, f"💰 Gold: _{data['gold']}_\n🍇 _Food: {data['food']}_")

	else:
		bot.send_message(message.from_user.id, f"💰 Gold: _{data['gold']}_\n🍇 _Food: {data['food']}_")



@bot.message_handler(commands = ["get_gold"], func = lambda message: message.from_user.id == 163494588)
def getGold(message):
	text = message.text.split(" ")[1:]

	if len(text) == 1:
		if not text[0].isdigit():
			bot.send_message(message.from_user.id, "Total gold not valid")
		else:
			cur.execute(f"UPDATE data SET gold = gold + {text[0]} WHERE id = 163494588")
			db.commit()
			bot.send_message(message.from_user.id, "Ok")
	elif len(text) == 2:
		if not text[1].isdigit():
			bot.send_message(message.from_user.id, "Total gold not valid")
		else:
			try:
				cur.execute(f"UPDATE data SET gold = gold + {text[1]} WHERE id = {text[0]}")
				db.commit()
				bot.send_message(message.from_user.id, "Ok")
			except:
				bot.send_message(message.from_user.id, "Failed")



@bot.message_handler(commands = ["companion"], func = lambda message: noInRoomBattle(message.from_user.id))
def getCompanionData(message):
	timeNow = int(time.time())
	cur.execute(f"SELECT * FROM companion WHERE owner = {message.from_user.id}")
	companionList = cur.fetchall()
	msg = ""
	current_gold = 0
	for i, companion in enumerate(companionList):
		companionObject = characters.characters[companion['name']](companion["level"])
		name = companionObject.name
		msg += f"{i + 1}. _{name}_ - _Level {companion['level']}_\n"
		current_gold += module.getTotalGold(companion["previousClaim"], companionObject.gpm, max = companionObject.maxGold)

	msg += f"\nCurrent gold: _{round(current_gold)}_"
	markup = module.inline(["Claim gold", "Increase slot"])
	bot.send_message(message.from_user.id, msg, reply_markup = markup)


# @bot.callback_query_handler(func = lambda call: call.data == "Add companion")
# def addCompanion(call):
# 	cur.execute(f"SELECT slot FROM data WHERE id = {call.message.chat.id}")
# 	user = cur.fetchone()
# 	cur.execute(f"SELECT name FROM companion WHERE owner = {call.message.chat.id}")
# 	totalCompanion = len(cur.fetchall())

# 	if user["slot"] <= totalCompanion:
# 		bot.answer_callback_query(callback_query_id = call.id, text = "You don't have a slot")
# 		return

# 	char_name = [CHARACTERS_NAME[i:i + 2] for i in range(0, len(CHARACTERS_NAME), 2)]
# 	markup = module.inline(*char_name)
# 	bot.send_photo(call.message.chat.id, open("images/Angel.jpg", "rb"), caption = "Select companion to follow you ⚔️", reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data == "Claim gold")
def claimGold(call):
	def getTotalGold(companion):
		companionObject = characters.characters[companion["name"]](companion["level"])
		return module.getTotalGold(companion["previousClaim"], companionObject.gpm, max = companionObject.maxGold)

	cur.execute(f"SELECT invitedBy FROM data WHERE id = {call.message.chat.id}")
	user = cur.fetchone()

	bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id)
	cur.execute(f"SELECT name, previousClaim, level FROM companion WHERE owner = {call.message.chat.id}")
	companionList = cur.fetchall()
	current_gold = map(getTotalGold, companionList)
	current_gold = round(sum(list(current_gold)))

	if current_gold < 10:
		bot.answer_callback_query(callback_query_id = call.id, text = "Minimum claim: 10")
		return

	if user["invitedBy"]:
		cur.execute(f"UPDATE data SET gold = gold + 10000, invited = invited + 1 WHERE id = {user['invitedBy']}")

	cur.execute(f"UPDATE data SET gold = gold + {current_gold}, invitedBy = NULL WHERE id = {call.message.chat.id}")
	cur.execute(f"UPDATE companion SET previousClaim = {int(time.time())} WHERE owner = {call.message.chat.id}")
	db.commit()
	bot.answer_callback_query(callback_query_id = call.id, text = f"Success claim {current_gold} gold")

	if user["invitedBy"]:
		bot.send_message(user["invitedBy"], f"*Congratulation !* {module.removeMarkdown(call.from_user.first_name)} claimed their gold 💰 for the first time , you received 10,000 💰 into your storage")


@bot.callback_query_handler(func = lambda call: call.data == "Increase slot")
def increaseSlot(call):
	bot.answer_callback_query(callback_query_id = call.id)
	cur.execute(f"SELECT slot, gold FROM data WHERE id = {call.message.chat.id}")
	companion = cur.fetchone()

	if companion["slot"] >= 10:
		bot.answer_callback_query(callback_query_id = call.id, text = "Your slot has maximal")
		return

	price = [25000, 50000, 75000, 125000, 200000, 350000, 450000, 700000, 1000000]

	msg = f"""
Are you sure you want to spend {price[companion['slot'] - 1]} to increase slot to {companion['slot'] + 1}? 
Your current gold is : {companion['gold']}
	"""

	markup = types.InlineKeyboardMarkup()
	markup.add(types.InlineKeyboardButton("Confirm", callback_data = "ConfirmSlot"), types.InlineKeyboardButton("Back", callback_data = "BackSlot"))
	bot.edit_message_text(msg, chat_id = call.message.chat.id, message_id = call.message.message_id, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data == "BackSlot")
@loadingFixed
def backToCompanion(call):
	timeNow = int(time.time())
	cur.execute(f"SELECT * FROM companion WHERE owner = {call.message.chat.id}")
	companionList = cur.fetchall()
	msg = ""
	current_gold = 0
	for i, companion in enumerate(companionList):
		companionObject = characters.characters[companion['name']](companion["level"])
		name = companionObject.name
		msg += f"{i + 1}. _{name}_ - _Level {companion['level']}_\n"
		current_gold += module.getTotalGold(companion["previousClaim"], companionObject.gpm, max = companionObject.maxGold)

	msg += f"\nCurrent gold: _{round(current_gold)}_"
	markup = module.inline(["Claim gold", "Increase slot"])
	bot.edit_message_text(msg, chat_id = call.message.chat.id, message_id = call.message.message_id, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data == "ConfirmSlot")
@loadingFixed
def confirmAddSlot(call):
	bot.edit_message_reply_markup(chat_id = call.message.chat.id, message_id = call.message.message_id)
	cur.execute(f"SELECT slot, gold FROM data WHERE id = {call.message.chat.id}")
	companion = cur.fetchone()
	price = [25000, 50000, 75000, 125000, 200000, 350000, 450000, 700000, 1000000]
	price = price[companion["slot"] - 1]

	if price > companion["gold"]:
		bot.send_message(call.message.chat.id, f"You don't have {price} gold")
		return

	cur.execute(f"UPDATE data SET slot = slot + 1, gold = gold - {price} WHERE id = {call.message.chat.id}")
	db.commit()
	bot.send_message(call.message.chat.id, "Success add slot")


@bot.message_handler(commands = ["stats"], func = lambda message: noInRoomBattle(message.from_user.id))
def getCompanionData(message):
	companionName = message.text.split(" ")[-1].capitalize()
	if not companionName in CHARACTERS_NAME_ASCII_ONLY:
		bot.reply_to(message, "Companion not found")
		return

	cur.execute(f"SELECT * FROM companion WHERE owner = {message.from_user.id}")
	myCompanion = cur.fetchall()

	companion = list(filter(lambda x: CHARACTERS_NAME_ASCII_ONLY[x["name"]] == companionName, myCompanion))
	if not companion:
		bot.reply_to(message, "You don't have that companion")
		return

	companionInDb = companion[0]
	companion = characters.characters[companionInDb["name"]](companionInDb["level"])
	exp = (f"{companionInDb['exp']}/{module.getExpRequirement(companionInDb['level'])}") if companionInDb["level"] < 100 else "Max"

	msg = f"""
      {companion.name}

Level : {companion.level}
Exp : {exp}
Element : {companion.element}
HP : {companion.hp}
Attack : {companion.attack}
Speed : {companion.speed}

💰 Gold production/min : {companion.gpm}
🗄 Max gold : {companion.maxGold}

⚔️ Default Moveset :
*{companion.first_skill_name}* : {companion.first_skill_info}

⚔️ Moveset unlock at level 50:
*{companion.second_skill_name}* : {companion.second_skill_info}
	"""


	markup = module.inline("Feed")
	SELECTED_COMPANION[message.from_user.id] = companionName

	if message.chat.type in ["supergroup", "group"]:
		bot.send_photo(message.chat.id, open(companion.imagePath, "rb"), caption = msg, reply_to_message_id = message.message_id)
	else:
		bot.send_photo(message.from_user.id, open(companion.imagePath, "rb"), caption = msg, reply_markup = markup)


@bot.message_handler(commands = ["mystats"])
def mystats(message):
	cur.execute(f"SELECT total_win, total_lose FROM data WHERE id = {message.from_user.id}")
	user = cur.fetchone()
	if not user:
		return

	msg = f"""
*{module.removeMarkdown(message.from_user.first_name)}*
*{message.from_user.id}*

⚔️ Total battle played : *{user['total_win'] + user['total_lose']}*
✅ Total win : *{user['total_win']}*
❌ Total loss : *{user['total_lose']}*
	"""

	if message.chat.type in ["supergroup", "group"]:
		bot.reply_to(message, msg)
	else:
		bot.send_message(message.from_user.id, msg)



@bot.callback_query_handler(func = lambda call: call.data == "Feed")
def giveFoodInStat(call):
	call.message.from_user.id = call.message.chat.id
	call.message.text = SELECTED_COMPANION[call.message.chat.id]
	del SELECTED_COMPANION[call.message.chat.id]
	bot.delete_message(call.message.chat.id, call.message.message_id)
	giveFood(call.message)


@bot.message_handler(commands = ["feed"], func = lambda message: noInRoomBattle(message.from_user.id))
def giveFood(message):
	companionName = message.text.split(" ")[-1].capitalize()
	if not companionName in CHARACTERS_NAME_ASCII_ONLY:
		bot.send_message(message.from_user.id, "Companion not found")
		return

	cur.execute(f"SELECT * FROM companion WHERE owner = {message.from_user.id}")
	myCompanion = cur.fetchall()

	cur.execute(f"SELECT food FROM data WHERE id = {message.from_user.id}")
	food = cur.fetchone()["food"]

	companion = list(filter(lambda x: CHARACTERS_NAME_ASCII_ONLY[x["name"]] == companionName, myCompanion))
	if not companion:
		bot.send_message(message.from_user.id, "You don't have that companion")
		return

	companion = companion[0]
	companionClass = characters.characters[companion["name"]]
	SELECTED_COMPANION[message.from_user.id] = companion
	exp = (f"{companion['exp']}/{module.getExpRequirement(companion['level'])}") if companion["level"] < 100 else "Max"

	msg = f"""
{companionClass.name}

Level : {companion['level']}
Exp : {exp}

Your foods: {food} 🍇
	"""

	markup = types.ForceReply()
	bot.send_photo(message.from_user.id, open(companionClass.imagePath, "rb"), caption = msg)
	bot.send_message(message.from_user.id, "Enter food amount :", reply_markup = markup)


@bot.message_handler(func = lambda message: message.reply_to_message and message.reply_to_message.text == "Enter food amount :" and noInRoomBattle(message.from_user.id))
def giveFood_(message):
	foodNeeded = message.text

	if not foodNeeded.isdigit():
		bot.send_message(message.from_user.id, "Total food not valid")
		return

	foodNeeded = int(foodNeeded)

	cur.execute(f"SELECT food FROM data WHERE id = {message.from_user.id}")
	user = cur.fetchone()
	companion = SELECTED_COMPANION[message.from_user.id]
	del SELECTED_COMPANION[message.from_user.id]

	if companion["level"] >= 100:
		bot.send_message(message.from_user.id, "Has reached the maximum level")
		return

	companionClass = characters.characters[companion["name"]]
	
	if user["food"] < foodNeeded:
		bot.send_message(message.from_user.id, f"You don't have {foodNeeded} food")
		return

	module.addExp(companion["companion_id"], foodNeeded, companion = companion)
	cur.execute(f"UPDATE data SET food = food - {foodNeeded} WHERE id = {message.from_user.id}")
	db.commit()

	bot.send_message(message.from_user.id, "Yummyy !!")


@bot.message_handler(commands = ["store"], func = lambda message: noInRoomBattle(message.from_user.id))
def shop(message):
	markup = module.inline(["Buy Food", "Buy Companion"])
	bot.send_message(message.from_user.id, "Welcome to store 🏫", reply_markup = markup)
	

@bot.callback_query_handler(func = lambda call: call.data == "Buy Food")
@loadingFixed
def buyFood(call):
	bot.edit_message_reply_markup(chat_id = call.message.chat.id, message_id = call.message.message_id)
	markup = types.ForceReply()

	cur.execute(f"SELECT gold FROM data WHERE id = {call.message.chat.id}")
	totalGold = cur.fetchone()["gold"]

	bot.send_message(call.message.chat.id, f"Enter your food amount :\n\n3 💰 =  1 🍇\n\nYour golds: {totalGold}", reply_markup = markup)


@bot.message_handler(func = lambda message: message.reply_to_message and message.reply_to_message.text and "Enter your food amount :" in message.reply_to_message.text and noInRoomBattle(message.from_user.id))
# @loadingFixed
def confirmBuyFood(message):
	cur.execute(f"SELECT gold FROM data WHERE id = {message.from_user.id}")
	user = cur.fetchone()

	total = message.text
	if not total.isdigit():
		bot.send_message(message.from_user.id, "Total food not valid")
		return

	total = int(total) 
	price = total * 3
	if price > user["gold"]:
		bot.send_message(message.from_user.id, f"You don't have {price} gold")
		return

	cur.execute(f"UPDATE data SET gold = gold - {price}, food = food + {total} WHERE id = {message.from_user.id}")
	db.commit()
	bot.send_message(message.from_user.id, "Success buy food")


@bot.callback_query_handler(func = lambda call: call.data == "Buy Companion")
@loadingFixed
def buyCompanion(call):
	# bot.answer_callback_query(callback_query_id = call.id)
	char_name = [CHARACTERS_NAME[i:i + 2] for i in range(0, len(CHARACTERS_NAME), 2)]
	markup = types.InlineKeyboardMarkup()
	for x in char_name:
		markup.row(*([types.InlineKeyboardButton(y, callback_data = "Buy " + y) for y in x]))

	bot.send_photo(call.message.chat.id, open("images/Angel.jpg", "rb"), caption = "Select one companion to follow you ⚔️", reply_markup = markup)


@bot.callback_query_handler(func = lambda call: re.search(r"^Buy ", call.data))
@loadingFixed
def selectCompanion(call):
	# bot.answer_callback_query(callback_query_id = call.id)
	index = CHARACTERS_NAME.index(call.data.replace("Buy ", ""))
	character = characters.characters[index]

	cur.execute(f"SELECT name FROM companion WHERE owner = {call.message.chat.id}")
	myCompanionName = [CHARACTERS_NAME[x["name"]] for x in cur.fetchall()]
	cur.execute(f"SELECT gold FROM data WHERE id = {call.message.chat.id}")
	totalGold = cur.fetchone()["gold"]

	companionPrice = [10000, 20000, 40000, 80000, 160000, 320000 ,640000 ,1280000, 2560000]
	companionPrice = companionPrice[len(myCompanionName) - 1]

	if call.data.replace("Buy ", "") in myCompanionName:
		bot.answer_callback_query(callback_query_id = call.id, text = "You already have this companion")
		return

	msg = f"""
      {character.name}

Element : {character.element}
HP : {character.hp}
Attack : {character.attack}
Speed : {character.speed}

💰 Gold production/min : {character.gpm}
🗄 Max gold : {character.maxGold}

⚔️ Default Moveset :
*{character.first_skill_name}* : {character.first_skill_info}

⚔️ Moveset unlock at level 50:
*{character.second_skill_name}* : {character.second_skill_info}

Your golds: {totalGold}
	"""

	SELECTED_COMPANION[call.message.chat.id] = character
	markup = module.inline(f"Buy Companion ({companionPrice} gold)", "Back")
	markup = types.InlineKeyboardMarkup()
	markup.add(types.InlineKeyboardButton(f"Buy Companion ({companionPrice} gold)", callback_data = "BuyCompanion"))
	markup.add(types.InlineKeyboardButton("Back", callback_data = "BackToCompanionShop"))
	bot.edit_message_media(types.InputMedia("photo", open(character.imagePath, "rb"), caption = msg, parse_mode = "Markdown"), chat_id = call.message.chat.id,
						message_id = call.message.message_id, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data == "BackToCompanionShop")
@loadingFixed
def backToCompanionShop(call):
	bot.answer_callback_query(callback_query_id = call.id)
	char_name = [CHARACTERS_NAME[i:i + 2] for i in range(0, len(CHARACTERS_NAME), 2)]
	markup = types.InlineKeyboardMarkup()
	for x in char_name:
		markup.row(*([types.InlineKeyboardButton(y, callback_data = "Buy " + y) for y in x]))

	bot.edit_message_media(types.InputMedia("photo", open("images/Angel.jpg", "rb"), caption = "Select one companion to follow you ⚔️", parse_mode = "Markdown"), chat_id = call.message.chat.id,
						message_id = call.message.message_id, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data == "BuyCompanion")
@loadingFixed
def confirmBuyCompanion(call):
	cur.execute(f"SELECT slot, gold FROM data WHERE id = {call.message.chat.id}")
	user = cur.fetchone()
	cur.execute(f"SELECT name FROM companion WHERE owner = {call.message.chat.id}")
	myCompanionNameList = [CHARACTERS_NAME[x["name"]] for x in cur.fetchall()]
	totalCompanion = len(myCompanionNameList)
	companionPrice = [10000, 20000, 40000, 80000, 160000, 320000 ,640000 ,1280000, 2560000]
	companionPrice = companionPrice[totalCompanion - 1]
	character = SELECTED_COMPANION[call.message.chat.id]
	del SELECTED_COMPANION[call.message.chat.id]

	if character.name in myCompanionNameList:
		bot.answer_callback_query(callback_query_id = call.id, text = "You already have this companion")
		return

	if user["slot"] <= totalCompanion:
		bot.answer_callback_query(callback_query_id = call.id, text = "You don't have a slot")
		return

	if companionPrice > user["gold"]:
		bot.answer_callback_query(callback_query_id = call.id, text = f"You don't have {companionPrice} gold")
		return

	cur.execute(f"INSERT INTO companion VALUES(NULL, 1, {call.message.chat.id}, {CHARACTERS_NAME.index(character.name)}, \
				{int(time.time())}, 0)")
	cur.execute(f"UPDATE data SET gold = gold - {companionPrice} WHERE id = {call.message.chat.id}")
	cur.execute(f"DELETE FROM position WHERE id = {call.message.chat.id}")
	db.commit()
	bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id)
	msg = f"""
Congratulations 🎊
You have selected {character.name} to be your companion.

Use /commands to see command lists.

Let the adventure begin ⚔️
		"""
	bot.send_message(call.message.chat.id, msg)


@bot.message_handler(commands = ["team"], func = lambda message: noInRoomBattle(message.from_user.id))
def editTeam(message):
	inlineButton = ["Change positions",  "Reset"]

	cur.execute(f"SELECT * FROM companion WHERE owner = {message.from_user.id}")
	myCompanionList = cur.fetchall()
	cur.execute(f"SELECT * FROM position WHERE id = {message.from_user.id}")
	position = cur.fetchone()

	if not position:
		companionList = myCompanionList[:3]
		position1 = companionList[0]["name"]
		position2 = companionList[1]["name"] if len(companionList) >= 2 else "NULL"
		position3 = companionList[2]["name"] if len(companionList) >= 3 else "NULL"
		# print(position1, position2, position3)
		cur.execute(f"INSERT INTO position VALUES({message.from_user.id}, {position1}, {position2}, {position3})")
		db.commit()
		cur.execute(f"SELECT * FROM position WHERE id = {message.from_user.id}")
		position = cur.fetchone()

	position = (position["position1"], position["position2"], position["position3"])

	if len(myCompanionList) > 3:
		inlineButton.insert(0, "Edit")
	markup = module.inline(*inlineButton)

	msg = ""
	for i, companionName in enumerate(position):
		if not companionName:
			continue
		msg += f"{i + 1}. {CHARACTERS_NAME[companionName]}\n"

	bot.send_message(message.from_user.id, msg, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data == "Reset")
def resetTeam(call):
	bot.edit_message_reply_markup(chat_id = call.message.chat.id, message_id = call.message.message_id)
	cur.execute(f"DELETE FROM position WHERE id = {call.message.chat.id}")
	db.commit()
	bot.send_message(call.message.chat.id, "Successfully")


@bot.callback_query_handler(func = lambda call: call.data == "Done")
def done(call):
	bot.edit_message_reply_markup(chat_id = call.message.chat.id, message_id = call.message.message_id)


@bot.callback_query_handler(func = lambda call: call.data == "Edit")
@loadingFixed
def editTeam_(call):
	cur.execute(f"SELECT * FROM companion WHERE owner = {call.message.chat.id}")
	myCompanionList = cur.fetchall()
	cur.execute(f"SELECT * FROM position WHERE id = {call.message.chat.id}")
	position = cur.fetchone()
	position = (position["position1"], position["position2"], position["position3"])

	markup = types.InlineKeyboardMarkup()
	for companion in myCompanionList:
		if not companion["name"] in position:
			markup.add(types.InlineKeyboardButton(CHARACTERS_NAME[companion["name"]], callback_data = f"ChangeTeam|{companion['name']}"))

	bot.edit_message_text("Select companion to enter your team:", chat_id = call.message.chat.id, message_id = call.message.message_id, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data.startswith("ChangeTeam"))
@loadingFixed
def changeTeam(call):
	cur.execute(f"SELECT * FROM companion WHERE owner = {call.message.chat.id}")
	myCompanionList = cur.fetchall()
	cur.execute(f"SELECT * FROM position WHERE id = {call.message.chat.id}")
	position = cur.fetchone()
	position = (position["position1"], position["position2"], position["position3"])

	markup = types.InlineKeyboardMarkup()
	for i, companionName in enumerate(position):
		markup.add(types.InlineKeyboardButton(CHARACTERS_NAME[companionName], callback_data = f"ConfirmChangeTeam|{call.data.split('|')[1]}|{i + 1}"))

	bot.edit_message_text("Change to:", chat_id = call.message.chat.id, message_id = call.message.message_id, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data.startswith("ConfirmChangeTeam"))
@loadingFixed
def confirmChangeTeam(call):
	bot.answer_callback_query(callback_query_id = call.id)
	target = call.data.split("|")[1]
	change_to = call.data.split("|")[2]

	cur.execute(f"SELECT * FROM position WHERE id = {call.message.chat.id}")
	position = cur.fetchone()
	position = (position["position1"], position["position2"], position["position3"])

	if target in position:
		bot.answer_callback_query(callback_query_id = call.id, text = "This companion has entered the team")
		return

	cur.execute(f"UPDATE position SET position{change_to} = {target}")
	db.commit()

	inlineButton = ["Change positions", "Reset"]

	cur.execute(f"SELECT * FROM companion WHERE owner = {call.message.chat.id}")
	myCompanionList = cur.fetchall()
	cur.execute(f"SELECT * FROM position WHERE id = {call.message.chat.id}")
	position = cur.fetchone()
	position = (position["position1"], position["position2"], position["position3"])

	if len(myCompanionList) > 3:
		inlineButton.insert(0, "Edit")
	markup = module.inline(*inlineButton)

	msg = ""
	for i, companionName in enumerate(position):
		if not companionName:
			continue
		msg += f"{i + 1}. {CHARACTERS_NAME[companionName]}\n"

	bot.edit_message_text(msg, chat_id = call.message.chat.id, message_id = call.message.message_id, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data == "Change positions")
@loadingFixed
def changePosition(call):
	cur.execute(f"SELECT * FROM companion WHERE owner = {call.message.chat.id}")
	myCompanionList = cur.fetchall()
	cur.execute(f"SELECT * FROM position WHERE id = {call.message.chat.id}")
	position = cur.fetchone()
	position = (position["position1"], position["position2"], position["position3"])

	if not position:
		companionList = myCompanionList[:3]
		position1 = companionList[0]
		position2 = companionList[1] if len(companionList) >= 2 else "NULL"
		position3 = companionList[2] if len(companionList) >= 3 else "NULL"
		cur.execute(f"INSERT INTO position VALUES({call.message.chat.id}, {position1}, {position2}, {position3})")
		db.commit()
		cur.execute(f"SELECT * FROM position WHERE id = {call.message.chat.id}")
		position = cur.fetchone()

	markup = types.InlineKeyboardMarkup()
	for i, companionName in enumerate(position):
		if not companionName:
			continue
		markup.add(types.InlineKeyboardButton(CHARACTERS_NAME[companionName], callback_data = f"ChangePosition|{i + 1}"))

	bot.edit_message_text("Select companion to swap position:", chat_id = call.message.chat.id, message_id = call.message.message_id, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data.startswith("ChangePosition"))
@loadingFixed
def changePosition_(call):
	cur.execute(f"SELECT * FROM companion WHERE owner = {call.message.chat.id}")
	myCompanionList = cur.fetchall()
	cur.execute(f"SELECT * FROM position WHERE id = {call.message.chat.id}")
	position = cur.fetchone()
	position = (position["position1"], position["position2"], position["position3"])

	if not position:
		companionList = myCompanionList[:3]
		position1 = companionList[0]
		position2 = companionList[1] if len(companionList) >= 2 else "NULL"
		position3 = companionList[2] if len(companionList) >= 3 else "NULL"
		cur.execute(f"INSERT INTO position VALUES({call.message.chat.id}, {position1}, {position2}, {position3})")
		db.commit()
		cur.execute(f"SELECT * FROM position WHERE id = {call.message.chat.id}")
		position = cur.fetchone()

	markup = types.InlineKeyboardMarkup()
	for i, companionName in enumerate(position):
		if not companionName:
			continue
		markup.add(types.InlineKeyboardButton(CHARACTERS_NAME[companionName], callback_data = f"ConfirmChangePosition|{call.data.split('|')[1]}|{i + 1}"))

	bot.edit_message_text("Swap to:", chat_id = call.message.chat.id, message_id = call.message.message_id, reply_markup = markup)


@bot.callback_query_handler(func = lambda call: call.data.startswith("ConfirmChangePosition"))
@loadingFixed
def confirmChangePosition(call):
	target = call.data.split("|")[1]
	swap_to = call.data.split("|")[2]

	cur.execute(f"UPDATE position SET position{target} = position{swap_to}, position{swap_to} = position{target}")
	db.commit()

	inlineButton = ["Change positions", "Reset"]

	cur.execute(f"SELECT * FROM companion WHERE owner = {call.message.chat.id}")
	myCompanionList = cur.fetchall()
	cur.execute(f"SELECT * FROM position WHERE id = {call.message.chat.id}")
	position = cur.fetchone()
	position = (position["position1"], position["position2"], position["position3"])

	if len(myCompanionList) > 3:
		inlineButton.insert(0, "Edit")
	markup = module.inline(*inlineButton)

	msg = ""
	for i, companionName in enumerate(position):
		if not companionName:
			continue
		msg += f"{i + 1}. {CHARACTERS_NAME[companionName]}\n"

	bot.edit_message_text(msg, chat_id = call.message.chat.id, message_id = call.message.message_id, reply_markup = markup)


@bot.message_handler(commands = ["referral"])
def referall(message):
	cur.execute(f"SELECT invited FROM data WHERE id = {message.from_user.id}")
	user = cur.fetchone()
	msg = f"""
Invite friends to join and receive great reward

You have invited : *{user['invited']}* friends 

Here is your link : 
[https://t.me/{bot.bot_info.username}?start={message.from_user.id}](https://t.me/{bot.bot_info.username}?start={message.from_user.id})
	"""
	# print(msg)
	bot.send_message(message.from_user.id, msg)


@bot.message_handler(commands = ["battle"], func = lambda message: message.chat.type in ["supergroup", "group"] and message.reply_to_message and \
					message.reply_to_message.from_user.id != message.from_user.id)
def battle(message):
	if True:
		cur.execute(f"SELECT * FROM data WHERE id = {message.reply_to_message.from_user.id}")
		user = cur.fetchone()
		cur.execute(f"SELECT * FROM companion WHERE owner = {message.reply_to_message.from_user.id}")
		companion = cur.fetchone()

		if not user or not companion:
			bot.reply_to(message, f"{module.createMention(message.reply_to_message.from_user)} dont have companion")
			return

		cur.execute(f"SELECT * FROM data WHERE id = {message.from_user.id}")
		user = cur.fetchone()
		cur.execute(f"SELECT * FROM companion WHERE owner = {message.from_user.id}")
		companion = cur.fetchone()

		if not user or not companion:
			bot.reply_to(message, f"{module.createMention(message.from_user)} dont have companion")
			return

	if message.from_user.id in IN_ROOM_BATTLE:
		bot.reply_to(message, "You is in battle")
		return

	if message.reply_to_message.from_user.id in IN_ROOM_BATTLE:
		bot.reply_to(message, module.createMention(message.reply_to_message.from_user) + " is in battle")
		return

	msg = bot.reply_to(message, f"{module.createMention(message.from_user)} invited {module.createMention(message.reply_to_message.from_user)} to battle!",
					reply_markup = module.inline(["Accept", "Reject", "Cancel"]))

	roomBattle = RoomBattle(message.chat, message.from_user, message.reply_to_message.from_user, msg.message_id)
	ROOM_BATTLE[message.from_user.id] = roomBattle
	ROOM_BATTLE[message.reply_to_message.from_user.id] = roomBattle


@bot.callback_query_handler(func = lambda call: call.data == "Accept")
@checkUser
def acceptBattle(call):
	roomBattle = ROOM_BATTLE[call.from_user.id]
	roomBattle.accept(call.from_user.id)


@bot.callback_query_handler(func = lambda call: call.data == "Reject")
@checkUser
def rejectBattle(call):
	roomBattle = ROOM_BATTLE[call.from_user.id]
	roomBattle.reject(call.from_user.id)


@bot.callback_query_handler(func = lambda call: call.data == "Cancel")
@checkUser
def cancelBattle(call):
	roomBattle = ROOM_BATTLE[call.from_user.id]
	roomBattle.cancel(call.from_user.id)


@bot.callback_query_handler(func = lambda call: call.data.startswith("attack1"))
@checkUser
@loadingFixed
def attack1(call):
	roomBattle = ROOM_BATTLE[call.from_user.id]

	if not roomBattle.player1_turn and roomBattle.player1_info.id == call.from_user.id:
		bot.answer_callback_query(callback_query_id = call.id, text = "Can't use this operation")
		return

	if roomBattle.player1_turn and roomBattle.player2_info.id == call.from_user.id:
		bot.answer_callback_query(callback_query_id = call.id, text = "Can't use this operation")		
		return

	roomBattle.attack1()


@bot.callback_query_handler(func = lambda call: call.data.startswith("attack2"))
@checkUser
@loadingFixed
def attack1(call):
	roomBattle = ROOM_BATTLE[call.from_user.id]

	if not roomBattle.player1_turn and roomBattle.player1_info.id == call.from_user.id:
		bot.answer_callback_query(callback_query_id = call.id, text = "Can't use this operation")
		return

	if roomBattle.player1_turn and roomBattle.player2_info.id == call.from_user.id:
		bot.answer_callback_query(callback_query_id = call.id, text = "Can't use this operation")		
		return

	if roomBattle.player1_turn and roomBattle.p1Companion().level < 50:
		bot.answer_callback_query(callback_query_id = call.id, text = "Need level 50 to unlock this")
		return

	if not roomBattle.player1_turn and roomBattle.p2Companion().level < 50:
		bot.answer_callback_query(callback_query_id = call.id, text = "Need level 50 to unlock this")
		return

	roomBattle.attack2()



# bot.infinity_polling()
# bot.polling(none_stop = True)
app.run(host = "0.0.0.0", port = int(os.environ.get("PORT", 5000)))